import React from 'react';
import TrackkerApp from './components/TrackkerApp';

function App() {
  return (
    <div className="App">
      <TrackkerApp />
    </div>
  );
}

export default App;